using System;
namespace devesh
{
    class Program
    {
        static void Main()
        {
            int a,b;
          a=5;
          b=++a;
          Console.WriteLine(a);
          Console.WriteLine(b);

        }
       }
    }
}
